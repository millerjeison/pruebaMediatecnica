export interface License {
  key: string;
  name: string;
  spdx_id: string;
  url: string;
  node_id: string;
}
